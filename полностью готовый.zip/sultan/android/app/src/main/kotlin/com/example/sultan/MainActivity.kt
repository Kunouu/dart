package com.example.sultan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
