const express = require('express');
const { Pool } = require('pg');
const cors = require('cors');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');

const app = express();

// Настроим CORS (если ваше Flutter-приложение работает с другого домена)
app.use(cors());

// Используем body-parser для парсинга JSON данных из тела запроса
app.use(bodyParser.json());

// Настроим подключение к базе данных PostgreSQL
const pool = new Pool({
  user: 'postgres', // замените на ваше имя пользователя PostgreSQL
  host: 'localhost',
  database: 'job_search_db', // замените на имя вашей базы данных
  password: '123', // замените на ваш пароль
  port: 5432, // обычно PostgreSQL работает на порту 5432
});

// Проверка подключения к базе данных
pool.connect()
  .then(() => console.log('Подключение к базе данных успешно!'))
  .catch(err => {
    console.error('Ошибка подключения к базе данных:', err.stack);
    process.exit(1); // Завершаем приложение, если не удается подключиться к базе данных
  });

// Логируем все входящие запросы
app.use((req, res, next) => {
  console.log(`${req.method} запрос на ${req.url}`);
  next();
});

// Роут для получения всех заявок компании (company_orders)
app.get('/company_orders', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM company_orders');
    console.log('Fetched company_orders:', result.rows);
    res.json(result.rows); // Отправляем данные в формате JSON
  } catch (error) {
    console.error('Ошибка при получении заявок компании:', error);
    res.status(500).send('Ошибка при получении заявок компании');
  }
});

// Роут для добавления новой заявки компании (company_orders)
app.post('/company_orders', async (req, res) => {
  const { company_name, programm_name, price, childrens_old, instagram, phone_number, city } = req.body;

  console.log('Received data for company_orders:', req.body);

  if (!company_name || !programm_name || !price || !childrens_old || !instagram || !phone_number || !city) {
    return res.status(400).json({ error: 'Все поля обязательны для заполнения' });
  }

  try {
    const checkQuery = 'SELECT * FROM company_orders WHERE phone_number = $1';
    const checkResult = await pool.query(checkQuery, [phone_number]);

    if (checkResult.rows.length > 0) {
      return res.status(400).json({ error: 'Заявка компании с таким номером телефона уже существует' });
    }

    const result = await pool.query(
      'INSERT INTO company_orders (company_name, programm_name, price, childrens_old, instagram, phone_number, city) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *',
      [company_name, programm_name, price, childrens_old, instagram, phone_number, city]
    );

    console.log('Inserted company_order:', result.rows[0]);
    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Ошибка при добавлении заявки компании:', error);
    res.status(500).json({ error: 'Ошибка при добавлении заявки компании' });
  }
});

// Роут для обновления заявки компании
app.put('/company_orders/:id', async (req, res) => {
  const { id } = req.params;
  const { company_name, programm_name, price, childrens_old, instagram, phone_number, city } = req.body;

  console.log('Received update data for company_orders:', req.body);

  if (!company_name || !programm_name || !price || !childrens_old || !instagram || !phone_number || !city) {
    return res.status(400).json({ error: 'Все поля обязательны для обновления' });
  }

  try {
    const checkQuery = 'SELECT * FROM company_orders WHERE phone_number = $1 AND id != $2';
    const checkResult = await pool.query(checkQuery, [phone_number, id]);

    if (checkResult.rows.length > 0) {
      return res.status(400).json({ error: 'Заявка компании с таким номером телефона уже существует' });
    }

    const result = await pool.query(
      'UPDATE company_orders SET company_name = $1, programm_name = $2, price = $3, childrens_old = $4, instagram = $5, phone_number = $6, city = $7 WHERE id = $8 RETURNING *',
      [company_name, programm_name, price, childrens_old, instagram, phone_number, city, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Заявка не найдена' });
    }

    console.log('Updated company_order:', result.rows[0]);
    res.status(200).json(result.rows[0]);
  } catch (error) {
    console.error('Ошибка при обновлении заявки компании:', error);
    res.status(500).json({ error: 'Ошибка при обновлении заявки компании' });
  }
});

// Роут для удаления заявки компании
app.delete('/company_orders/:id', async (req, res) => {
  const { id } = req.params;

  try {
    const result = await pool.query('DELETE FROM company_orders WHERE id = $1 RETURNING *', [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Заявка не найдена' });
    }

    console.log('Deleted company_order:', result.rows[0]);
    res.status(200).json({ message: 'Заявка успешно удалена' });
  } catch (error) {
    console.error('Ошибка при удалении заявки компании:', error);
    res.status(500).json({ error: 'Ошибка при удалении заявки компании' });
  }
});

// Роут для получения всех заявок пользователей (user_orders)
app.get('/user_orders', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM user_orders');
    console.log('Fetched user_orders:', result.rows);
    res.json(result.rows); // Отправляем данные в формате JSON
  } catch (error) {
    console.error('Ошибка при получении заявок пользователей:', error);
    res.status(500).send('Ошибка при получении заявок пользователей');
  }
});

// Роут для добавления новой заявки пользователя (user_orders)
app.post('/user_orders', async (req, res) => {
  const { user_name, programm, users_budjet, childrens_old, adress, phone_number, city } = req.body;

  console.log('Received data for user_orders:', req.body);

  if (!user_name || !programm || !users_budjet || !childrens_old || !adress || !phone_number || !city) {
    return res.status(400).json({ error: 'Все поля обязательны для заполнения' });
  }

  try {
    const checkQuery = 'SELECT * FROM user_orders WHERE phone_number = $1';
    const checkResult = await pool.query(checkQuery, [phone_number]);

    if (checkResult.rows.length > 0) {
      return res.status(400).json({ error: 'Заявка с таким номером телефона уже существует' });
    }

    const result = await pool.query(
      'INSERT INTO user_orders (user_name, programm, users_budjet, childrens_old, adress, phone_number, city) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *',
      [user_name, programm, users_budjet, childrens_old, adress, phone_number, city]
    );

    console.log('Inserted user_order:', result.rows[0]);
    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Ошибка при добавлении заявки пользователя:', error);
    res.status(500).json({ error: 'Ошибка при добавлении заявки пользователя' });
  }
});

// Роут для регистрации пользователя
app.post('/register', async (req, res) => {
  const { name, email, phone_number, password, role } = req.body;

  if (!name || !email || !phone_number || !password || !role) {
    return res.status(400).json({ error: 'Все поля обязательны для заполнения' });
  }

  const saltRounds = 10;
  const passwordHash = await bcrypt.hash(password, saltRounds);

  try {
    const result = await pool.query(
      'INSERT INTO users (name, email, phone_number, password_hash, role) VALUES ($1, $2, $3, $4, $5) RETURNING *',
      [name, email, phone_number, passwordHash, role]
    );

    console.log('Inserted user:', result.rows[0]);
    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Ошибка при регистрации пользователя:', error);
    res.status(500).json({ error: 'Ошибка при регистрации пользователя' });
  }
});

// Роут для входа
app.post('/login', async (req, res) => {
  const { phone_number, password, role } = req.body;

  if (!phone_number || !password || !role) {
    return res.status(400).json({ error: 'Все поля обязательны для входа' });
  }

  try {
    const result = await pool.query(
      'SELECT * FROM users WHERE phone_number = $1 AND role = $2',
      [phone_number, role]
    );

    if (result.rows.length === 0) {
      return res.status(400).json({ error: 'Пользователь не найден или неверная роль' });
    }

    const user = result.rows[0];
    const match = await bcrypt.compare(password, user.password_hash);

    if (!match) {
      return res.status(400).json({ error: 'Неверный пароль' });
    }

    res.status(200).json(user); // Возвращаем пользователя при успешном входе
  } catch (error) {
    console.error('Ошибка при входе:', error);
    res.status(500).json({ error: 'Ошибка при входе' });
  }
});

// Обработка всех других маршрутов (если клиент пытается запросить несуществующий маршрут)
app.use((req, res) => {
  res.status(404).json({ error: 'Ресурс не найден' });
});

// Запускаем сервер
const port = 3000;
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
