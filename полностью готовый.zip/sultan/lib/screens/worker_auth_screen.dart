import 'package:flutter/material.dart';

class WorkerAuthScreen extends StatefulWidget {
  @override
  _WorkerAuthScreenState createState() => _WorkerAuthScreenState();
}

class _WorkerAuthScreenState extends State<WorkerAuthScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _isLogin = true;

  void _authenticate() {
    if (_emailController.text.isEmpty || _passwordController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Пожалуйста, заполните все поля')),
      );
      return;
    }

    if (_isLogin) {
      if (_emailController.text != "worker@example.com" || _passwordController.text != "password") {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Неверный email или пароль')),
        );
        return;
      }
    } else {
      if (_emailController.text == "worker@example.com") {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Этот email уже зарегистрирован')),
        );
        return;
      }
    }

    Navigator.pushReplacementNamed(context, '/workerMainPage');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          _isLogin ? 'Вход (Клиент)' : 'Регистрация (Клиент)',
          style: TextStyle(color: Colors.white), // Белый текст для контраста
        ),
        backgroundColor: Colors.purpleAccent, // Фиолетовый цвет для AppBar
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: _emailController,
              decoration: InputDecoration(
                labelText: 'Email',
                labelStyle: TextStyle(color: Colors.purpleAccent), // Цвет метки
                focusedBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.purpleAccent), // Цвет подчеркивания при фокусе
                ),
              ),
              keyboardType: TextInputType.emailAddress,
            ),
            SizedBox(height: 10),
            TextField(
              controller: _passwordController,
              decoration: InputDecoration(
                labelText: 'Пароль',
                labelStyle: TextStyle(color: Colors.purpleAccent), // Цвет метки
                focusedBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.purpleAccent), // Цвет подчеркивания при фокусе
                ),
              ),
              obscureText: true,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _authenticate,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.purpleAccent, // Цвет кнопки
                padding: EdgeInsets.symmetric(vertical: 12, horizontal: 24), // Увеличенный размер кнопки
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)), // Скругленные углы
              ),
              child: Text(
                _isLogin ? 'Войти' : 'Зарегистрироваться',
                style: TextStyle(color: Colors.white), // Белый цвет текста
              ),
            ),
            TextButton(
              onPressed: () {
                setState(() {
                  _isLogin = !_isLogin;
                });
              },
              child: Text(
                _isLogin ? 'Создать аккаунт' : 'Уже есть аккаунт? Войти',
                style: TextStyle(color: Colors.purpleAccent), // Цвет текста
              ),
            ),
          ],
        ),
      ),
    );
  }
}
