import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../models/company_order.dart';
import '../providers/company_order_provider.dart';

class AddJobScreen extends StatefulWidget {
  @override
  _AddJobScreenState createState() => _AddJobScreenState();
}

class _AddJobScreenState extends State<AddJobScreen> {
  final _companyNameController = TextEditingController();
  final _programmNameController = TextEditingController();
  final _priceController = TextEditingController();
  final _childrensOldController = TextEditingController();
  final _instagramController = TextEditingController();
  final _phoneNumberController = TextEditingController();
  final _cityController = TextEditingController();

  final _formKey = GlobalKey<FormState>();
  bool _isLoading = false; // Статус загрузки

  // Метод для отправки данных на сервер и добавления вакансии
  Future<void> _saveJob() async {
    if (_formKey.currentState!.validate()) {
      final job = CompanyOrder(
        id: DateTime.now().toString(),  // Генерация уникального id
        companyName: _companyNameController.text,
        programmName: _programmNameController.text,
        price: _priceController.text,
        childrensOld: _childrensOldController.text,
        instagram: _instagramController.text,
        phoneNumber: _phoneNumberController.text,
        city: _cityController.text,
      );

      setState(() {
        _isLoading = true; // Устанавливаем флаг загрузки
      });

      try {
        // Логируем данные перед отправкой
        print('Sending data:');
        print({
          'company_name': job.companyName,
          'programm_name': job.programmName,
          'price': job.price,
          'childrens_old': job.childrensOld,
          'instagram': job.instagram,
          'phone_number': job.phoneNumber,
          'city': job.city,
        });

        final url = 'http://localhost:3000/company_orders'; // URL вашего сервера
        final response = await http.post(
          Uri.parse(url),
          headers: {'Content-Type': 'application/json'},
          body: json.encode({
            'company_name': job.companyName,
            'programm_name': job.programmName,
            'price': job.price,
            'childrens_old': job.childrensOld,
            'instagram': job.instagram,
            'phone_number': job.phoneNumber,
            'city': job.city,
          }),
        );

        setState(() {
          _isLoading = false; // Снимаем флаг загрузки
        });

        if (response.statusCode == 201) {
          print('Вакансия успешно добавлена!');
          // Добавляем вакансию в локальный список после успешного добавления
          Provider.of<CompanyOrderProvider>(context, listen: false).addOrder(job);

          // Очищаем форму после добавления
          _companyNameController.clear();
          _programmNameController.clear();
          _priceController.clear();
          _childrensOldController.clear();
          _instagramController.clear();
          _phoneNumberController.clear();
          _cityController.clear();

          // Показываем сообщение об успешном добавлении
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Вакансия успешно добавлена!')),
          );
        } else {
          // Обработка ошибок от сервера, если код ответа не 201
          print('Не удалось добавить вакансию. Код ответа: ${response.statusCode}');
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Ошибка при добавлении вакансии: ${response.statusCode}')),
          );
        }
      } catch (error) {
        setState(() {
          _isLoading = false; // Снимаем флаг загрузки
        });

        print('Ошибка при добавлении вакансии: $error');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Ошибка при добавлении вакансии. Пожалуйста, попробуйте снова.')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Добавить вакансию'),
        backgroundColor: Color(0xFF8E67A0), // Глубокий лиловый оттенок
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFF0E6F6), Color(0xFFDFD3E2)], // Легкий пастельный градиент
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              children: [
                TextFormField(
                  controller: _companyNameController,
                  decoration: InputDecoration(labelText: 'Компания'),
                  validator: (value) => value!.isEmpty ? 'Введите название компании' : null,
                ),
                TextFormField(
                  controller: _programmNameController,
                  decoration: InputDecoration(labelText: 'Программа'),
                  validator: (value) => value!.isEmpty ? 'Введите программу' : null,
                ),
                TextFormField(
                  controller: _priceController,
                  decoration: InputDecoration(labelText: 'Цена'),
                  validator: (value) => value!.isEmpty ? 'Введите цену' : null,
                ),
                TextFormField(
                  controller: _childrensOldController,
                  decoration: InputDecoration(labelText: 'Возраст детей'),
                  validator: (value) => value!.isEmpty ? 'Введите возраст детей' : null,
                ),
                TextFormField(
                  controller: _instagramController,
                  decoration: InputDecoration(labelText: 'Instagram'),
                  validator: (value) => value!.isEmpty ? 'Введите Instagram' : null,
                ),
                TextFormField(
                  controller: _phoneNumberController,
                  decoration: InputDecoration(labelText: 'Номер телефона'),
                  keyboardType: TextInputType.number,
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Введите номер телефона';
                    } else if (value.length < 10) { // Проверка длины номера
                      return 'Введите корректный номер';
                    }
                    return null;
                  },
                ),
                TextFormField(
                  controller: _cityController,
                  decoration: InputDecoration(labelText: 'Город'),
                  validator: (value) => value!.isEmpty ? 'Введите город' : null,
                ),
                SizedBox(height: 20),
                _isLoading
                    ? CircularProgressIndicator() // Показываем индикатор загрузки
                    : ElevatedButton(
                  onPressed: _saveJob,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF8E67A0), // Лиловый цвет кнопки
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12), // Скругленные углы
                    ),
                  ),
                  child: Text(
                    'Сохранить вакансию',
                    style: TextStyle(color: Colors.white), // Белый текст
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
