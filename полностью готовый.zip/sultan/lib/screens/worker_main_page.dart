import 'package:flutter/material.dart';
import 'worker_resume_search_screen.dart'; // Экран поиска резюме
import 'applied_client_screen.dart'; // Экран откликов
import 'add_user_orders_screen.dart'; // Экран для добавления заявок

class WorkerMainPage extends StatefulWidget {
  @override
  _WorkerMainPageState createState() => _WorkerMainPageState();
}

class _WorkerMainPageState extends State<WorkerMainPage> {
  int _currentIndex = 0;

  // Список экранов для переключения
  final List<Widget> _screens = [
    WorkerResumeSearchScreen(), // Экран поиска резюме
    AppliedResumesScreen(), // Экран откликов
    AddResumeScreen(), // Экран для добавления заявок
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Основная страница клиента',
          style: TextStyle(color: Colors.white), // Белый текст для контраста
        ),
        backgroundColor: Colors.purpleAccent, // Фиолетовый цвет для AppBar
        actions: [
          IconButton(
            icon: Icon(Icons.exit_to_app, color: Colors.white), // Белая иконка выхода
            onPressed: () {
              Navigator.pushReplacementNamed(context, '/roleSelection'); // Переход к экрану выбора роли
            },
          ),
        ],
      ),
      body: _screens[_currentIndex], // Показываем экран в зависимости от выбранной вкладки
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index; // Переключаем вкладки
          });
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.search),
            label: 'Поиск',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.bookmark),
            label: 'Отклики',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.add),
            label: 'Добавить заявку', // Вкладка для добавления заявки
          ),
        ],
        selectedItemColor: Colors.purpleAccent, // Выделение выбранной вкладки фиолетовым
        unselectedItemColor: Colors.grey, // Неактивные вкладки с серым цветом
        backgroundColor: Colors.white, // Белый фон для BottomNavigationBar
      ),
    );
  }
}
