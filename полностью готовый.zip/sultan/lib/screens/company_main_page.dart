import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/company_order_provider.dart';
import 'company_search_screen.dart';
import 'applied_company_screen.dart';
import 'add_company_order_screen.dart';

class CompanyMainPage extends StatefulWidget {
  @override
  _CompanyMainPageState createState() => _CompanyMainPageState();
}

class _CompanyMainPageState extends State<CompanyMainPage> {
  int _currentIndex = 0;

  final _screens = [
    SearchScreen(), // Экран поиска
    AppliedJobsScreen(), // Экран откликов
    AddJobScreen(), // Экран добавления вакансии
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Главный экран компании',
          style: TextStyle(color: Colors.white), // Белый текст в AppBar
        ),
        backgroundColor: Colors.purpleAccent, // Фиолетовый цвет для AppBar
        actions: [
          IconButton(
            icon: Icon(Icons.exit_to_app),
            onPressed: () {
              Navigator.pushReplacementNamed(context, '/roleSelection'); // Возврат к выбору роли
            },
          ),
        ],
      ),
      body: _screens[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.search),
            label: 'Поиск',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.bookmark),
            label: 'Отклики',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.add),
            label: 'Добавить вакансию',
          ),
        ],
        selectedItemColor: Colors.purpleAccent, // Фиолетовый цвет для выбранного элемента
        unselectedItemColor: Colors.grey, // Серый цвет для невыбранных элементов
        type: BottomNavigationBarType.fixed, // Добавление фиксированного типа
      ),
    );
  }
}
