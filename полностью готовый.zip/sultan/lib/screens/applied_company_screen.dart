import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/user_orders.dart';
import '../providers/resume_provider.dart';

class AppliedJobsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final resumeProvider = Provider.of<ResumeProvider>(context);
    final appliedResumes = resumeProvider.appliedResumes;

    return DefaultTabController(
      length: 2, // Две вкладки: отклики и приглашения
      child: Scaffold(
        appBar: AppBar(
          title: Text('Отклики'),
          backgroundColor: Color(0xFF8E67A0), // Глубокий лиловый оттенок
          bottom: TabBar(
            tabs: [
              Tab(text: 'Отклики'),
            ],
            indicatorColor: Colors.white, // Белая линия под вкладкой
          ),
        ),
        body: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFFF0E6F6), Color(0xFFDFD3E2)], // Легкий пастельный градиент
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: TabBarView(
            children: [
              // Вкладка откликов
              appliedResumes.isEmpty
                  ? Center(
                child: Text(
                  'Вы пока не откликнулись на предложения.',
                  style: TextStyle(fontSize: 18, color: Color(0xFF5D3D7E)), // Цвет текста
                ),
              )
                  : ListView.builder(
                itemCount: appliedResumes.length,
                itemBuilder: (ctx, index) {
                  final resume = appliedResumes[index];
                  return Card(
                    elevation: 4,
                    margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12), // Скругленные углы
                    ),
                    child: ListTile(
                      title: Text(
                        resume.user_name,
                        style: TextStyle(color: Color(0xFF5D3D7E), fontWeight: FontWeight.bold), // Заголовок
                      ),
                      subtitle: Text(
                        resume.programm,
                        style: TextStyle(color: Color(0xFF8E67A0)), // Подзаголовок
                      ),
                      trailing: ElevatedButton(
                        onPressed: () {
                          resumeProvider.cancelApplication(resume);
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.red, // Красная кнопка
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8), // Скругленные углы
                          ),
                        ),
                        child: Text(
                          'Отменить отклик',
                          style: TextStyle(color: Colors.white), // Белый текст
                        ),
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
