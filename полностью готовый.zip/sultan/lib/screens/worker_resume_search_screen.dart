import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/company_order.dart'; // Модель для компании
import '../providers/company_order_provider.dart'; // Провайдер для компании
import 'company_order_detail_screen.dart'; // Экран с деталями заявки компании

class WorkerResumeSearchScreen extends StatefulWidget {
  @override
  _WorkerResumeSearchScreenState createState() =>
      _WorkerResumeSearchScreenState();
}

class _WorkerResumeSearchScreenState extends State<WorkerResumeSearchScreen> {
  TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';

  @override
  void initState() {
    super.initState();
    // Загружаем заявки компании при инициализации экрана
    Provider.of<CompanyOrderProvider>(context, listen: false).fetchOrders();
  }

  @override
  Widget build(BuildContext context) {
    final companyOrderProvider = Provider.of<CompanyOrderProvider>(context);
    final companyOrders = companyOrderProvider.companyOrders;
    final appliedCompanyOrders = companyOrderProvider.appliedCompanyOrders;

    // Фильтрация заявок компании по поисковому запросу
    final filteredCompanyOrders = _searchQuery.isEmpty
        ? companyOrders
        : companyOrders.where((companyOrder) {
      final lowerQuery = _searchQuery.toLowerCase();
      return companyOrder.companyName.toLowerCase().contains(lowerQuery) ||
          companyOrder.programmName.toLowerCase().contains(lowerQuery) ||
          companyOrder.price.toLowerCase().contains(lowerQuery) ||
          companyOrder.childrensOld.toLowerCase().contains(lowerQuery) ||
          companyOrder.city.toLowerCase().contains(lowerQuery);
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Поиск заявок компании',
          style: TextStyle(color: Colors.white), // Белый цвет для текста
        ),
        backgroundColor: Colors.purpleAccent, // Фиолетовый цвет для AppBar
        centerTitle: true,
      ),
      body: Column(
        children: [
          // Поле для ввода поискового запроса
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              controller: _searchController,
              onChanged: (value) {
                setState(() {
                  _searchQuery = value;
                });
              },
              decoration: InputDecoration(
                labelText: 'Поиск по названию компании, программе, цене, возрасту детей или городу',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                filled: true,
                fillColor: Colors.white, // Белый фон для поля ввода
              ),
            ),
          ),
          Expanded(
            child: filteredCompanyOrders.isEmpty
                ? Center(
              child: Text(
                'Заявки компании не найдены.',
                style: TextStyle(fontSize: 18),
              ),
            )
                : ListView.builder(
              itemCount: filteredCompanyOrders.length,
              itemBuilder: (ctx, index) {
                final companyOrder = filteredCompanyOrders[index];
                final isApplied = appliedCompanyOrders.contains(companyOrder);

                return Card(
                  color: isApplied ? Colors.grey[300] : null, // Если откликнулись, то фон серый
                  elevation: 4,
                  margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10), // Закругленные углы
                  ),
                  child: ListTile(
                    title: Text(
                      companyOrder.companyName,
                      style: TextStyle(fontWeight: FontWeight.bold), // Выделяем название компании
                    ),
                    subtitle: Text(
                      '${companyOrder.programmName}, ${companyOrder.price}',
                      style: TextStyle(fontSize: 16),
                    ),
                    trailing: Icon(Icons.arrow_forward, color: Colors.purpleAccent),
                    onTap: () {
                      // Переход к экрану с деталями заявки компании
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (ctx) => CompanyOrderDetailScreen(companyOrder: companyOrder),
                        ),
                      );
                    },
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
