import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/user_orders.dart';
import '../providers/resume_provider.dart';

class ResumeDetailScreen extends StatefulWidget {
  final Resume resume;

  ResumeDetailScreen({required this.resume});

  @override
  _ResumeDetailScreenState createState() => _ResumeDetailScreenState();
}

class _ResumeDetailScreenState extends State<ResumeDetailScreen> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<Offset> _animation;
  bool _isFlying = false; // Флаг для отслеживания состояния анимации
  bool _hasApplied = false; // Флаг для отслеживания состояния отклика

  @override
  void initState() {
    super.initState();

    // Создаем контроллер анимации
    _controller = AnimationController(
      duration: Duration(seconds: 2), // Увеличиваем длительность анимации для плавности
      vsync: this,
    );

    // Анимация полета самолета
    _animation = Tween<Offset>(
      begin: Offset(-9, 0), // Начальная позиция: за пределами экрана слева
      end: Offset(15, 0),    // Конечная позиция: за пределами экрана справа
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: Curves.easeInOut,  // Плавное изменение скорости
    ));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _applyForResume(Resume resume, ResumeProvider resumeProvider) {
    if (!_isFlying && !_hasApplied) { // Проверяем, не откликались ли мы и не началась ли анимация
      if (!resumeProvider.appliedResumes.contains(resume)) { // Проверка, есть ли уже отклик
        resumeProvider.applyToResume(resume);
        setState(() {
          _hasApplied = true; // Устанавливаем флаг отклика
        });
        _controller.forward(); // Запускаем анимацию
        setState(() {
          _isFlying = true; // Устанавливаем флаг, чтобы анимация не запускалась повторно
        });

        // После завершения анимации можно выполнить другие действия, например, закрыть экран
        Future.delayed(Duration(seconds: 1), () {
          Navigator.pop(context);
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final resumeProvider = Provider.of<ResumeProvider>(context);

    return Scaffold(
      appBar: AppBar(title: Text(widget.resume.programm)),
      body: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.resume.programm,
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 8),
                Text('Имя: ${widget.resume.user_name}', style: TextStyle(fontSize: 18)),
                SizedBox(height: 16),
                Text('Номер: ${widget.resume.phone_number}', style: TextStyle(fontSize: 18)),
                SizedBox(height: 8),
                Text('Город: ${widget.resume.city}', style: TextStyle(fontSize: 18)),
                SizedBox(height: 16),
                Text(
                  'Навыки: ',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 8),
                Text(widget.resume.childrens_old, style: TextStyle(fontSize: 16)),
                Spacer(),
                ElevatedButton(
                  onPressed: _hasApplied // Кнопка отключена, если отклик уже отправлен
                      ? null
                      : () {
                    _applyForResume(widget.resume, resumeProvider);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _hasApplied ? Colors.grey : Colors.green,
                  ),
                  child: Text(_hasApplied ? 'Уже откликнулись' : 'Откликнуться'),
                ),
              ],
            ),
          ),
          // Анимация самолетика
          Positioned(
            left: _isFlying ? MediaQuery.of(context).size.width : -60, // Начало с левой стороны экрана
            top: 100,
            child: SlideTransition(
              position: _animation,
              child: Image.asset('images/airplane.png', width: 50, height: 50), // Замените на ваш путь к изображению самолетика
            ),
          ),
        ],
      ),
    );
  }
}
