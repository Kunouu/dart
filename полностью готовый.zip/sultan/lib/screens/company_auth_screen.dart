import 'package:flutter/material.dart';

class CompanyAuthScreen extends StatefulWidget {
  @override
  _CompanyAuthScreenState createState() => _CompanyAuthScreenState();
}

class _CompanyAuthScreenState extends State<CompanyAuthScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _isLogin = true;

  void _authenticate() {
    if (_emailController.text.isEmpty || _passwordController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Пожалуйста, заполните все поля')),
      );
      return;
    }

    if (_isLogin) {
      if (_emailController.text != "company@example.com" || _passwordController.text != "password") {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Неверный email или пароль')),
        );
        return;
      }
    } else {
      if (_emailController.text == "company@example.com") {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Этот email уже зарегистрирован')),
        );
        return;
      }
    }

    Navigator.pushReplacementNamed(context, '/companyMainPage');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          _isLogin ? 'Вход (Компания)' : 'Регистрация (Компания)',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.purpleAccent, // Добавляем фиолетовый цвет для AppBar
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextField(
                controller: _emailController,
                decoration: InputDecoration(
                  labelText: 'Email',
                  labelStyle: TextStyle(color: Colors.purple), // Цвет метки
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide(color: Colors.purple), // Скругленные углы и фиолетовая обводка
                  ),
                ),
                keyboardType: TextInputType.emailAddress,
              ),
              SizedBox(height: 20),
              TextField(
                controller: _passwordController,
                decoration: InputDecoration(
                  labelText: 'Пароль',
                  labelStyle: TextStyle(color: Colors.purple), // Цвет метки
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide(color: Colors.purple), // Скругленные углы и фиолетовая обводка
                  ),
                ),
                obscureText: true,
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _authenticate,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.purpleAccent, // Цвет кнопки
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10), // Скругленные углы для кнопки
                  ),
                  padding: EdgeInsets.symmetric(horizontal: 32, vertical: 12), // Отступы для кнопки
                ),
                child: Text(
                  _isLogin ? 'Войти' : 'Зарегистрироваться',
                  style: TextStyle(fontSize: 16),
                ),
              ),
              SizedBox(height: 20),
              TextButton(
                onPressed: () {
                  setState(() {
                    _isLogin = !_isLogin;
                  });
                },
                style: TextButton.styleFrom(
                  foregroundColor: Colors.purple, textStyle: TextStyle(fontSize: 16),
                ),
                child: Text(
                  _isLogin ? 'Создать аккаунт' : 'Уже есть аккаунт? Войти',
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
