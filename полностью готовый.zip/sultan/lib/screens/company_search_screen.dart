import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/user_orders.dart';
import '../providers/resume_provider.dart';
import '../widgets/company_order_card.dart';
import 'user_order_detail_screen.dart';

class SearchScreen extends StatefulWidget {
  @override
  _SearchScreenState createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';

  @override
  void initState() {
    super.initState();
    // Загружаем резюме при инициализации экрана
    Provider.of<ResumeProvider>(context, listen: false).fetchResumes();
  }

  @override
  Widget build(BuildContext context) {
    final resumeProvider = Provider.of<ResumeProvider>(context);
    final resumes = resumeProvider.resumes;
    final appliedResumes = resumeProvider.appliedResumes;

    // Фильтруем резюме на основе поискового запроса
    final filteredResumes = _searchQuery.isEmpty
        ? resumes
        : resumes
        .where((resume) => resume.programm.toLowerCase().contains(_searchQuery.toLowerCase()))
        .toList();

    return Scaffold(
      appBar: AppBar(
        title: Text('Поиск программе'),
        backgroundColor: Color(0xFF8E67A0), // Глубокий лиловый оттенок
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFF0E6F6), Color(0xFFDFD3E2)], // Легкий пастельный градиент
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Column(
          children: [
            // Поле ввода для поиска
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: TextField(
                controller: _searchController,
                onChanged: (value) {
                  setState(() {
                    _searchQuery = value;
                  });
                },
                decoration: InputDecoration(
                  labelText: 'Поиск по программе',
                  labelStyle: TextStyle(color: Color(0xFF5D3D7E)), // Цвет для метки
                  prefixIcon: Icon(Icons.search, color: Color(0xFF5D3D7E)), // Цвет иконки
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: Color(0xFF8E67A0)), // Лиловый контур
                  ),
                ),
              ),
            ),
            Expanded(
              child: filteredResumes.isEmpty
                  ? Center(
                child: Text(
                  'Заявки не найдены.',
                  style: TextStyle(fontSize: 18, color: Color(0xFF5D3D7E)), // Цвет текста
                ),
              )
                  : ListView.builder(
                itemCount: filteredResumes.length,
                itemBuilder: (ctx, index) {
                  final resume = filteredResumes[index];
                  final isApplied = appliedResumes.contains(resume);

                  return ResumeCard(
                    title: resume.user_name,
                    company: resume.programm,
                    onTap: () {
                      // Навигация на экран деталей резюме
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (ctx) => ResumeDetailScreen(resume: resume),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
