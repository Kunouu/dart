import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/company_order.dart';
import '../providers/company_order_provider.dart';

class AppliedResumesScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final companyOrderProvider = Provider.of<CompanyOrderProvider>(context);
    final appliedOrders = companyOrderProvider.appliedOrders;

    return DefaultTabController(
      length: 2, // Две вкладки: отклики и приглашения
      child: Scaffold(
        appBar: AppBar(
          title: Text('Отклики'),
          backgroundColor: Colors.purpleAccent, // Мягкий цвет фона для AppBar
          bottom: TabBar(
            tabs: [
              Tab(text: 'Отклики'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            // Вкладка откликов
            appliedOrders.isEmpty
                ? Center(
              child: Text(
                'Вы пока не откликнулись на программы.',
                style: TextStyle(fontSize: 18, color: Colors.purple[700]), // Мягкий цвет текста
              ),
            )
                : ListView.builder(
              itemCount: appliedOrders.length,
              itemBuilder: (ctx, index) {
                final companyOrder = appliedOrders[index];
                return Card(
                  elevation: 6,
                  margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15), // Скругленные углы
                  ),
                  shadowColor: Colors.purple.withOpacity(0.3), // Тень с мягким фиолетовым оттенком
                  child: ListTile(
                    contentPadding: EdgeInsets.symmetric(vertical: 12, horizontal: 16), // Отступы
                    title: Text(
                      companyOrder.programmName, // Название вакансии
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    subtitle: Text(
                      companyOrder.companyName, // Название компании
                      style: TextStyle(color: Colors.purple[600]),
                    ),
                    trailing: ElevatedButton(
                      onPressed: () {
                        companyOrderProvider.cancelApplication(companyOrder);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red, // Цвет кнопки отмены
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10), // Скругленные углы для кнопки
                        ),
                        padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8), // Отступы внутри кнопки
                      ),
                      child: Text(
                        'Отменить отклик',
                        style: TextStyle(fontSize: 14),
                      ),
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
