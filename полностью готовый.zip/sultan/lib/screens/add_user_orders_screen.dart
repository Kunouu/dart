import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../models/user_orders.dart';
import '../providers/resume_provider.dart';

class AddResumeScreen extends StatefulWidget {
  @override
  _AddResumeScreenState createState() => _AddResumeScreenState();
}

class _AddResumeScreenState extends State<AddResumeScreen> {
  final _user_nameController = TextEditingController();
  final _programmController = TextEditingController();
  final _users_budjetController = TextEditingController();
  final _childrens_oldController = TextEditingController();
  final _adressController = TextEditingController();
  final _phone_numberController = TextEditingController();
  final _cityController = TextEditingController();

  final _formKey = GlobalKey<FormState>();
  bool _isLoading = false;

  // Метод для отправки данных на сервер и добавления резюме в базу данных
  Future<void> _saveResume() async {
    if (_formKey.currentState!.validate()) {
      final resume = Resume(
        id: DateTime.now().toString(),
        user_name: _user_nameController.text,
        programm: _programmController.text,
        users_budjet: _users_budjetController.text,
        childrens_old: _childrens_oldController.text,
        adress: _adressController.text,
        phone_number: _phone_numberController.text,
        city: _cityController.text,
      );

      setState(() {
        _isLoading = true;
      });

      try {
        print('Sending data:');
        print({
          'user_name': resume.user_name,
          'programm': resume.programm,
          'users_budjet': resume.users_budjet,
          'childrens_old': resume.childrens_old,
          'adress': resume.adress,
          'phone_number': resume.phone_number,
          'city': resume.city,
        });

        final url = 'http://localhost:3000/user_orders';
        final response = await http.post(
          Uri.parse(url),
          headers: {'Content-Type': 'application/json'},
          body: json.encode({
            'user_name': resume.user_name,
            'programm': resume.programm,
            'users_budjet': resume.users_budjet,
            'childrens_old': resume.childrens_old,
            'adress': resume.adress,
            'phone_number': resume.phone_number,
            'city': resume.city,
          }),
        );

        setState(() {
          _isLoading = false;
        });

        if (response.statusCode == 201) {
          print('Резюме успешно добавлено!');
          Provider.of<ResumeProvider>(context, listen: false).addResume(resume);

          _user_nameController.clear();
          _programmController.clear();
          _users_budjetController.clear();
          _childrens_oldController.clear();
          _adressController.clear();
          _phone_numberController.clear();
          _cityController.clear();

          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Резюме успешно добавлено!')),
          );
        } else {
          print('Не удалось добавить резюме. Код ответа: ${response.statusCode}');
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Ошибка при добавлении резюме: ${response.statusCode}')),
          );
        }
      } catch (error) {
        setState(() {
          _isLoading = false;
        });

        print('Ошибка при добавлении резюме: $error');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Ошибка при добавлении резюме. Пожалуйста, попробуйте снова.')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Добавить заявку'),
        backgroundColor: Colors.purpleAccent, // Мягкий цвет фона для AppBar
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              children: [
                TextFormField(
                  controller: _user_nameController,
                  decoration: InputDecoration(
                    labelText: 'Имя',
                    labelStyle: TextStyle(color: Colors.purple[700]), // Мягкий цвет для лейбла
                    focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.purple[700]!)), // Цвет подчеркивания
                  ),
                  validator: (value) => value!.isEmpty ? 'Введите имя' : null,
                ),
                SizedBox(height: 12),
                TextFormField(
                  controller: _programmController,
                  decoration: InputDecoration(
                    labelText: 'Программа',
                    labelStyle: TextStyle(color: Colors.purple[700]),
                    focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.purple[700]!)),
                  ),
                  validator: (value) => value!.isEmpty ? 'Введите желаемую программу' : null,
                ),
                SizedBox(height: 12),
                TextFormField(
                  controller: _users_budjetController,
                  decoration: InputDecoration(
                    labelText: 'Бюджет',
                    labelStyle: TextStyle(color: Colors.purple[700]),
                    focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.purple[700]!)),
                  ),
                  validator: (value) => value!.isEmpty ? 'Введите ваш бюджет' : null,
                ),
                SizedBox(height: 12),
                TextFormField(
                  controller: _childrens_oldController,
                  decoration: InputDecoration(
                    labelText: 'Возраст',
                    labelStyle: TextStyle(color: Colors.purple[700]),
                    focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.purple[700]!)),
                  ),
                  validator: (value) => value!.isEmpty ? 'Введите возраст детей' : null,
                ),
                SizedBox(height: 12),
                TextFormField(
                  controller: _adressController,
                  decoration: InputDecoration(
                    labelText: 'Адрес',
                    labelStyle: TextStyle(color: Colors.purple[700]),
                    focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.purple[700]!)),
                  ),
                  validator: (value) => value!.isEmpty ? 'Укажите адрес по которому необходимы аниматоры' : null,
                ),
                SizedBox(height: 12),
                TextFormField(
                  controller: _phone_numberController,
                  decoration: InputDecoration(
                    labelText: 'Номер',
                    labelStyle: TextStyle(color: Colors.purple[700]),
                    focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.purple[700]!)),
                  ),
                  keyboardType: TextInputType.number,
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Введите номер телефона';
                    } else if (value.length < 10) {
                      return 'Введите корректный номер';
                    }
                    return null;
                  },
                ),
                SizedBox(height: 12),
                TextFormField(
                  controller: _cityController,
                  decoration: InputDecoration(
                    labelText: 'Город',
                    labelStyle: TextStyle(color: Colors.purple[700]),
                    focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.purple[700]!)),
                  ),
                  validator: (value) => value!.isEmpty ? 'Введите город' : null,
                ),
                SizedBox(height: 20),
                _isLoading
                    ? CircularProgressIndicator() // Показываем индикатор загрузки
                    : ElevatedButton(
                  onPressed: _saveResume,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.deepPurple, // Цвет кнопки
                    padding: EdgeInsets.symmetric(vertical: 15.0),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20.0), // Скругленные углы
                    ),
                  ),
                  child: Text(
                    'Сохранить заявку',
                    style: TextStyle(fontSize: 18, color: Colors.white),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
