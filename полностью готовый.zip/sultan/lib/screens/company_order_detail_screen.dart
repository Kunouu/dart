import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/company_order.dart';
import '../providers/company_order_provider.dart'; // Импортируем правильный провайдер

class CompanyOrderDetailScreen extends StatefulWidget {
  final CompanyOrder companyOrder;

  CompanyOrderDetailScreen({required this.companyOrder});

  @override
  _CompanyOrderDetailScreenState createState() => _CompanyOrderDetailScreenState();
}

class _CompanyOrderDetailScreenState extends State<CompanyOrderDetailScreen> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<Offset> _animation;
  bool _isFlying = false; // Флаг для отслеживания состояния анимации

  @override
  void initState() {
    super.initState();

    // Создаем контроллер анимации
    _controller = AnimationController(
      duration: Duration(seconds: 2), // Увеличиваем длительность анимации для плавности
      vsync: this,
    );

    // Анимация полета самолета
    _animation = Tween<Offset>(begin: Offset(-9, 0), end: Offset(15, 0)).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut), // Плавное изменение скорости
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _applyForJob(CompanyOrder companyOrder, CompanyOrderProvider companyOrderProvider) {
    if (!_isFlying) { // Если анимация еще не запущена
      if (!companyOrderProvider.appliedOrders.contains(companyOrder)) { // Проверяем, не был ли заказ уже добавлен
        companyOrderProvider.applyToOrder(companyOrder); // Добавляем вакансию в список откликов
        _controller.forward(); // Запускаем анимацию
        setState(() {
          _isFlying = true; // Устанавливаем флаг, чтобы анимация не запускалась повторно
        });

        // После завершения анимации можно выполнить другие действия, например, закрыть экран
        Future.delayed(Duration(seconds: 1), () {
          Navigator.pop(context); // Закрытие экрана после отклика
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final companyOrderProvider = Provider.of<CompanyOrderProvider>(context); // Используем правильный провайдер

    // Проверяем, есть ли заказ в корзине
    final isInCart = companyOrderProvider.appliedOrders.contains(widget.companyOrder);

    return Scaffold(
      appBar: AppBar(title: Text(widget.companyOrder.programmName)),
      body: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(widget.companyOrder.programmName, style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                SizedBox(height: 8),
                Text('Компания: ${widget.companyOrder.companyName}', style: TextStyle(fontSize: 18)),
                SizedBox(height: 16),
                Text('Цена: ${widget.companyOrder.price}', style: TextStyle(fontSize: 18)),
                SizedBox(height: 8),
                Text('Возраст детей: ${widget.companyOrder.childrensOld}', style: TextStyle(fontSize: 18)),
                SizedBox(height: 16),
                Text('Instagram: ${widget.companyOrder.instagram}', style: TextStyle(fontSize: 18)),
                SizedBox(height: 8),
                Text('Телефон: ${widget.companyOrder.phoneNumber}', style: TextStyle(fontSize: 18)),
                SizedBox(height: 16),
                Text('Город: ${widget.companyOrder.city}', style: TextStyle(fontSize: 18)),
                Spacer(),
                ElevatedButton(
                  onPressed: isInCart // Кнопка отключена, если вакансия уже в корзине
                      ? null
                      : () {
                    _applyForJob(widget.companyOrder, companyOrderProvider); // Откликаемся на вакансию
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: isInCart ? Colors.grey : Colors.green, // Изменяем цвет, если в корзине
                  ),
                  child: Text(isInCart ? 'В корзине' : 'Откликнуться'), // Изменяем текст
                ),
              ],
            ),
          ),
          // Анимация самолетика
          Positioned(
            left: _isFlying ? MediaQuery.of(context).size.width : -60, // Начало с левой стороны экрана
            top: 100,
            child: SlideTransition(
              position: _animation,
              child: Image.asset('images/airplane.png', width: 50, height: 50), // Замените на ваш путь к изображению самолетика
            ),
          ),
        ],
      ),
    );
  }
}
