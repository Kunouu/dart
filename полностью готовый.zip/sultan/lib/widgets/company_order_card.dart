// lib/widgets/company_order_card.dart
import 'package:flutter/material.dart';

class ResumeCard extends StatelessWidget {
  final String title;
  final String company;
  final VoidCallback onTap;

  ResumeCard({required this.title, required this.company, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(10),
      child: ListTile(
        title: Text(title),
        subtitle: Text(company),
        onTap: onTap,
      ),
    );
  }
}
