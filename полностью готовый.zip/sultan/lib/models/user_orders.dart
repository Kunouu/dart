class Resume {
  final String id;
  final String user_name;
  final String programm;
  final String users_budjet;
  final String childrens_old;
  final String adress;
  final String phone_number;  // Изменено на String, т.к. в базе данных это VARCHAR
  final String city;

  Resume({
    required this.id,
    required this.user_name,
    required this.programm,
    required this.users_budjet,
    required this.childrens_old,
    required this.adress,
    required this.phone_number,
    required this.city,
  });

  // Фабричный конструктор для преобразования JSON в объект
  factory Resume.fromJson(Map<String, dynamic> json) {
    print("Parsing resume: $json");  // Отладочное сообщение для проверки парсинга

    return Resume(
      id: json['id']?.toString() ?? '',  // Преобразуем id в строку
      user_name: json['user_name'] ?? '',
      programm: json['programm'] ?? '',
      users_budjet: json['users_budjet'] ?? '',
      childrens_old: json['childrens_old'] ?? '',
      adress: json['adress'] ?? '',
      phone_number: json['phone_number'] ?? '',  // Для номера телефона по умолчанию пустая строка
      city: json['city'] ?? '',
    );
  }

  // Метод для преобразования объекта в JSON
  Map<String, dynamic> toJson() {
    return {
      'user_name': user_name,
      'programm': programm,
      'users_budjet': users_budjet,
      'childrens_old': childrens_old,
      'adress': adress,
      'phone_number': phone_number,  // Строка для номера телефона
      'city': city,
    };
  }
}
