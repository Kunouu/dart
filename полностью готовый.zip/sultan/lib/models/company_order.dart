// lib/models/company_order.dart
class CompanyOrder {
  final String id; // Уникальный идентификатор заявки
  final String companyName; // Название компании
  final String programmName; // Название программы (вакансии)
  final String price; // Цена за программу
  final String childrensOld; // Возраст детей
  final String instagram; // Instagram компании
  final String phoneNumber; // Телефонный номер
  final String city; // Город, где размещена вакансия

  CompanyOrder({
    required this.id,
    required this.companyName,
    required this.programmName,
    required this.price,
    required this.childrensOld,
    required this.instagram,
    required this.phoneNumber,
    required this.city,
  });

  // Фабричный конструктор для преобразования JSON в объект
  factory CompanyOrder.fromJson(Map<String, dynamic> json) {
    print("Parsing company order: $json");  // Отладочное сообщение для проверки парсинга

    return CompanyOrder(
      id: json['id']?.toString() ?? '',  // Преобразуем id в строку, если оно есть
      companyName: json['company_name'] ?? '',  // Название компании
      programmName: json['programm_name'] ?? '',  // Название программы
      price: json['price'] ?? '',  // Цена за программу
      childrensOld: json['childrens_old'] ?? '',  // Возраст детей
      instagram: json['instagram'] ?? '',  // Instagram компании
      phoneNumber: json['phone_number'] ?? '',  // Номер телефона
      city: json['city'] ?? '',  // Город
    );
  }

  // Метод для преобразования объекта в JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'company_name': companyName,
      'programm_name': programmName,
      'price': price,
      'childrens_old': childrensOld,
      'instagram': instagram,
      'phone_number': phoneNumber,
      'city': city,
    };
  }
}
