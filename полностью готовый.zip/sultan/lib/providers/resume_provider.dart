import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../models/user_orders.dart';

class ResumeProvider with ChangeNotifier {
  List<Resume> _resumes = [];
  List<Resume> _appliedResumes = [];

  // Загружаем резюме с сервера
  Future<void> fetchResumes() async {
    final url = 'http://127.0.0.1:3000/user_orders'; // Обновленный URL для вашей базы данных
    try {
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final List<dynamic> responseData = json.decode(response.body);

        // Добавим отладочные сообщения, чтобы проверить данные
        print("Data received: $responseData");

        _resumes = responseData
            .map((data) => Resume.fromJson(data))
            .toList(); // Преобразуем JSON в объекты Resume

        // Уведомляем слушателей об изменении
        notifyListeners();
      } else {
        print("Failed to load resumes: ${response.statusCode}");
        throw Exception('Failed to load resumes');
      }
    } catch (error) {
      print("Error while fetching resumes: $error");
      throw Exception('Failed to load resumes: $error');
    }
  }

  // Возвращаем список резюме
  List<Resume> get resumes => [..._resumes];

  // Метод для подачи отклика на резюме
  void applyToResume(Resume resume) {
    if (!_appliedResumes.contains(resume)) {
      _appliedResumes.add(resume);
      notifyListeners();
    }
  }

  // Метод для отмены отклика на резюме
  void cancelApplication(Resume resume) {
    _appliedResumes.remove(resume);
    notifyListeners();
  }

  // Возвращаем список откликнутых резюме
  List<Resume> get appliedResumes => [..._appliedResumes];

  // Метод для добавления нового резюме
  Future<void> addResume(Resume resume) async {
    final url = 'http://localhost:3000/user_orders'; // Обновленный URL для вашей базы данных
    try {
      final response = await http.post(
        Uri.parse(url),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(resume.toJson()),
      );

      if (response.statusCode == 201) {
        print('Резюме успешно добавлено!');
        _resumes.add(resume);
        notifyListeners(); // Уведомляем слушателей о новом резюме
      } else {
        print("Failed to add resume: ${response.statusCode}");
        throw Exception('Failed to add resume');
      }
    } catch (error) {
      print("Error while adding resume: $error");
      throw Exception('Failed to add resume: $error');
    }
  }
}
