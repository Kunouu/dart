import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../models/company_order.dart';

class CompanyOrderProvider with ChangeNotifier {
  List<CompanyOrder> _orders = []; // Список заказов компании
  List<CompanyOrder> _appliedOrders = []; // Список откликнувшихся заказов

  bool _isLoading = false; // Состояние загрузки
  String _errorMessage = ''; // Сообщение об ошибке

  // Геттеры для получения списка заказов
  List<CompanyOrder> get companyOrders => [..._orders];
  List<CompanyOrder> get appliedCompanyOrders => [..._appliedOrders];

  // Загружаем заказы с сервера
  Future<void> fetchOrders() async {
    final url = 'http://localhost:3000/company_orders';
    _isLoading = true;

    // Отложим вызов notifyListeners, чтобы избежать ошибки во время билда
    Future.delayed(Duration.zero, () {
      notifyListeners();
    });

    try {
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final List<dynamic> responseData = json.decode(response.body);

        _orders = responseData
            .map((data) => CompanyOrder.fromJson(data))
            .toList(); // Преобразуем JSON в объекты CompanyOrder

        _errorMessage = ''; // Очищаем сообщение об ошибке
      } else {
        _errorMessage = 'Не удалось загрузить заказы. Попробуйте позже.';
      }
    } catch (error) {
      _errorMessage = 'Ошибка загрузки данных: $error';
    } finally {
      _isLoading = false;
      // Вновь вызываем notifyListeners, чтобы обновить UI
      notifyListeners();
    }
  }

  // Метод для подачи отклика на заказ
  void applyToOrder(CompanyOrder order) {
    if (!_appliedOrders.contains(order)) {
      _appliedOrders.add(order);
      notifyListeners();
    }
  }

  // Метод для отмены отклика на заказ
  void cancelApplication(CompanyOrder order) {
    _appliedOrders.remove(order);
    notifyListeners();
  }

  // Метод для добавления нового заказа
  Future<void> addOrder(CompanyOrder order) async {
    final url = 'http://10.0.2.2:3000/company_orders'; // URL для эмулятора Android
    try {
      final response = await http.post(
        Uri.parse(url),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(order.toJson()), // Преобразуем объект в JSON
      );

      if (response.statusCode == 201) {
        _orders.add(order); // Добавляем новый заказ в список
        notifyListeners(); // Уведомляем слушателей о новом заказе
      } else {
        throw Exception('Не удалось добавить заказ');
      }
    } catch (error) {
      _errorMessage = 'Ошибка добавления заказа: $error';
      notifyListeners(); // Обновляем UI с ошибкой
      print("Error while adding order: $error");
    }
  }

  // Возвращаем состояние загрузки
  bool get isLoading => _isLoading;

  // Возвращаем сообщение об ошибке
  String get errorMessage => _errorMessage;

  // Возвращаем список откликнувшихся заказов
  List<CompanyOrder> get appliedOrders => [..._appliedOrders];
}
