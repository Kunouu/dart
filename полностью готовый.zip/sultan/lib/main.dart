import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/company_order_provider.dart';
import 'providers/resume_provider.dart';
import 'screens/role_selection_screen.dart';
import 'screens/company_main_page.dart';
import 'screens/worker_main_page.dart';
import 'screens/company_auth_screen.dart';
import 'screens/worker_auth_screen.dart';
import 'screens/company_search_screen.dart'; // Добавляем экран поиска резюме
import 'screens/worker_resume_search_screen.dart'; // Экран для поиска резюме работника

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => CompanyOrderProvider()),
        ChangeNotifierProvider(create: (_) => ResumeProvider()),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Job Search App',
        theme: ThemeData(primarySwatch: Colors.blue),
        initialRoute: '/roleSelection',
        routes: {
          '/roleSelection': (context) => RoleSelectionScreen(),
          '/companyAuth': (context) => CompanyAuthScreen(), // Авторизация компании
          '/workerAuth': (context) => WorkerAuthScreen(), // Авторизация работника
          '/companyMainPage': (context) => CompanyMainPage(),
          '/workerMainPage': (context) => WorkerMainPage(),
          '/companySearchScreen': (context) => SearchScreen(), // Экран поиска компании
          '/workerResumeSearchScreen': (context) => WorkerResumeSearchScreen(), // Экран поиска резюме работника
        },
      ),
    );
  }
}
