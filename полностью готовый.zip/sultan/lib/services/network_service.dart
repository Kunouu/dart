// lib/services/network_service.dart

import 'dart:convert';
import 'package:http/http.dart' as http;

class NetworkService {
  final String baseUrl = 'http://localhost:3000'; // Адрес вашего сервера

  Future<List<dynamic>> fetchUsers() async {
    final response = await http.get(Uri.parse('$baseUrl/workers'));

    if (response.statusCode == 200) {
      List<dynamic> users = json.decode(response.body);
      return users;
    } else {
      throw Exception('Failed to load users');
    }
  }
}
